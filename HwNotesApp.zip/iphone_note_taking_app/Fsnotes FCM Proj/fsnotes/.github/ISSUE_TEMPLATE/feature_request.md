---
name: Feature Request
about: Suggest an idea for this project
title: ''
labels: 'request'
assignees: ''

---

<!-- NOTE: ignoring this template will lead to your issue being dealt with more slowly -->

**Describe your feature request**
A clear and concise description of what you want to happen.

**Additional context**
Add any other related information here. macOS or iOS?
