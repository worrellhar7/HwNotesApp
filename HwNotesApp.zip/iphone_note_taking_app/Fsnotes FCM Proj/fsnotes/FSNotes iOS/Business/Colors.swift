//
//  Colors.swift
//  FSNotes iOS
//
//  Created by Oleksandr Glushchenko on 9/15/18.
//  Copyright © 2018 Oleksandr Glushchenko. All rights reserved.
//

import UIKit

class Colors {
    public static var underlineColor: UIColor {
        return UIColor.black
    }
}
