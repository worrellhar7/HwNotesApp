//
//  Toolbar.swift
//  FSNotes iOS
//
//  Created by Oleksandr Glushchenko on 9/3/18.
//  Copyright © 2018 Oleksandr Glushchenko. All rights reserved.
//

enum Toolbar: Int {
    case markdown = 0x00
    case rich = 0x01
    case plain = 0x02
    case none = 0x04
}
