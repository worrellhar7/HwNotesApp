//
//  PreviewStateswift
//  FSNotes
//
//  Created by Олександр Глущенко on 20.09.2020.
//  Copyright © 2020 Oleksandr Glushchenko. All rights reserved.
//

public enum PreviewState: String {
    case on
    case off
}
