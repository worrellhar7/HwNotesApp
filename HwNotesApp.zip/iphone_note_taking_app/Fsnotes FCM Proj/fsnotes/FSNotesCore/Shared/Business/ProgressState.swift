//
//  ActionState.swift
//  FSNotes
//
//  Created by Олександр Глущенко on 20.09.2020.
//  Copyright © 2020 Oleksandr Glushchenko. All rights reserved.
//

public enum ProgressState: String {
    case none
    case incomplete
    case done
}
