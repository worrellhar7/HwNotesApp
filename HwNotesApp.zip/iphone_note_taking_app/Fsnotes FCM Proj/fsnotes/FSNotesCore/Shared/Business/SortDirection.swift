//
//  SortDirection.swift
//  FSNotes
//
//  Created by Олександр Глущенко on 8/20/19.
//  Copyright © 2019 Oleksandr Glushchenko. All rights reserved.
//

import Foundation

public enum SortDirection: String {
    case asc
    case desc
}
