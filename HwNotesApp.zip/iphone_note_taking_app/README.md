attempt at building a notes app via codesnack
